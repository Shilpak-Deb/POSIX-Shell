#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <termios.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <utility>

#include "shell_commands.h"

using namespace std;

//Global variable to store the pid of the process currently running in the foreground
int current_pid = -1;
//Global variable to keep track of what data has been read
string data_read = "";

//Function to return starting prompt
string prompt() {
    string home_directory = getHome();
    string prom = username() + "@" + systemname() + ":";
    string curr_directory = currentpath();
    bool in_home;
    if(curr_directory.size() < home_directory.size()) in_home = false;
    else in_home = curr_directory.substr(0, home_directory.size()) == home_directory;
    if(in_home) {
        if(home_directory == curr_directory) prom += "~>";
        else {
            string temp = curr_directory.substr(home_directory.size());
            if(temp.at(0) != '/') prom += "~/" + temp + ">";
            else prom += "~" + temp + ">";
        }
    }
    else prom += curr_directory + ">";
    prom += " ";
    return prom;
}

//Function to read a single line of input
string readline() {
    string line = "";

    data_read = line;
    arrow_index = -1;
    string arrow_data = "";
    bool arrow_pressed = false;
    bool tab_pressed = false;

    terminal_rawmode(true);
    while(true) {
        char ch = getchar();
        if(ch != '\t' && tab_pressed) tab_pressed = false;
        //Ctrl-D pressed
        if(ch == '\004') {
            exitTerminal = true;
            printf("\n");
            terminal_rawmode(false);
            return "";
        }
        //Arrow Keys pressed
        else if (ch == '\033') {
            ch = getchar();
            if (ch == '[') {
                ch = getchar();
                if (ch == 'A') {
                    arrow_data = up_arrow();
                    arrow_pressed = true;
                }
                else if (ch == 'B') {
                    arrow_data = down_arrow();
                    arrow_pressed = true;
                }
                continue;
            }
        }
        //Backspace pressed
        else if(ch == '\177') {
            if(arrow_pressed) {
                if(arrow_index == -1) {
                    if(!data_read.empty()) {
                        data_read.pop_back();
                        printf("\b \b\r%s%s", (prompt()).c_str(), data_read.c_str());
                    }
                }
                else {
                    if(!arrow_data.empty()) {
                        arrow_data.pop_back();
                        printf("\b \b\r%s%s", (prompt()).c_str(), arrow_data.c_str());
                    }
                }
            }
            else {
                if(!line.empty()) {
                    line.pop_back();
                    printf("\b \b\r%s%s", (prompt()).c_str(), line.c_str());
                }
            }
            continue;
        }
        //Tab pressed
        else if(ch == '\t') {
            if(tab_pressed) {
                if(arrow_pressed) {
                    if(arrow_index == -1) {
                        autocomplete2(data_read);
                        terminal_rawmode(false);
                        return "";
                    }
                    else {
                        autocomplete2(arrow_data);
                        terminal_rawmode(false);
                        return "";
                    }
                }
                else {
                    autocomplete2(line);
                    terminal_rawmode(false);
                    return "";
                }
            }
            else {
                if(arrow_pressed) {
                    if(arrow_index == -1) {
                        data_read = autocomplete1(data_read);
                    }
                    else {
                        arrow_data = autocomplete1(arrow_data);
                    }
                }
                else {
                    line = autocomplete1(line);
                }
            }
            tab_pressed = true;
            continue;
        }
        else printf("%c", ch);

        if(ch == '\n') {
            if(arrow_pressed) {
                if(arrow_index == -1) line = data_read;
                else line = arrow_data;
            }
            break;
        }
        else {
            if(arrow_pressed) {
                if(arrow_index == -1) data_read += ch;
                else arrow_data += ch;
            }
            else line += ch;
        }

        if(!arrow_pressed) data_read = line;
    }
    terminal_rawmode(false);
    return line;
}

//Function to execute a single command
void run_command(vector<string>& comm_args, bool is_background) {
    //Condition to exit terminal
    if(comm_args[0] == "exit") {
        exitTerminal = true;
        return;
    }
    //Condition to execute the 'pwd' command
    else if(comm_args[0] == "pwd") {
        printf("%s\n", (currentpath()).c_str());
        return;
    }
    //Calling user-made command 'cd'
    else if(comm_args[0] == "cd") {
        cd(comm_args);
        return;
    }
    //Calling the user-made command 'echo'
    else if(comm_args[0] == "echo") {
        print_echo(comm_args);
        return;
    }
    //Calling the user-made command 'ls'
    else if(comm_args[0] == "ls") {
        show_ls(comm_args);
        return;
    }
    //Calling user-made command 'pinfo'
    else if(comm_args[0] == "pinfo") {
        pinfo(comm_args);
        return;
    }
    //Calling user-made command 'history'
    else if(comm_args[0] == "history") {
        history(comm_args);
        return;
    }
    //Calling user-made command 'search'
    else if(comm_args[0] == "search") {
        search_in(comm_args);
        return;
    }
    int pid = fork();
    //Error condition for fork()
    if(pid == -1) {
        perror("Error encountered in forking process");
        return;
    }
    //Child process
    if(pid == 0) {
        const char* command = comm_args[0].c_str();
        char * args[comm_args.size()+1];
        for(int i = 0; i < comm_args.size(); i++) args[i] = comm_args[i].data();
        args[comm_args.size()] = NULL;

        if(execvp(command, args) == -1) {
            perror("Could not execute command");
            _exit(1); 
        }
    }
    //Parent process
    else {
        if(is_background) {
            printf("%d\n", pid);
            //Setting a separate group ID for child process from inside parent process
            if (setpgid(pid, pid) == -1) {
                perror("Error encountered in setting group ID for background process");
                return;
            }
        }
        else {
            current_pid = pid;

            while(true) {
                if(process_status(pid) == "T" || process_status(pid) == "Z" || process_status(pid) == "") break;
                usleep(1);
            }

            if(process_status(pid) == "Z") waitpid(pid, NULL, 0);
        }
    }
}

//Function to parse the arguments of the individual commands and execute them
void parse_commands(string command_line) {
    vector<string> command_args;
    //Checking if the argument is completely composed of ' ' or '\t'
    for(int i = 0; i < command_line.size(); i++) {
        if(command_line.at(i) != ' ' && command_line.at(i) != '\t') break;
        if(i == command_line.size()-1) return;
    }
    //Removing additonal ' ' and '\t' from beginning of argument
    while(command_line.at(0) == ' ' || command_line.at(0) == '\t') {
        command_line = command_line.substr(1);
    }
    string commline_copy = command_line;
    char* argument = strtok(command_line.data(), " \t");
    while(argument != NULL) {
        string temp = string(argument);
        if(command_args.size() == 1 && (command_args[0] == "echo" || command_args[0] == "search")) {
            char comm_endchar = command_args[0].at(command_args[0].size()-1);
            int index = command_args[0].size()-1;
            while(!isalpha(commline_copy.at(++index)) && !isdigit(commline_copy.at(index)));
            temp = commline_copy.substr(index);
            char firstchar = commline_copy.at(index-1);
            char lastchar = temp.at(temp.size()-1);
            if(firstchar == '\'' || firstchar == '\"') temp = firstchar + temp;
            command_args.push_back(temp);
            break;
        }
        command_args.push_back(temp);
        argument = strtok(NULL, " \t");
    }
    if(command_args[command_args.size()-1] == "&") {
        command_args.pop_back();
        run_command(command_args, true);
    }
    else run_command(command_args, false);
}

//Function to run I/O redirection
void run_IO(vector<string> io_operators, vector<string> io_args) {
    if(io_args.size() == 1) {
        printf("(Erroneous i/o redirector '%s' removed from the end of command line)\n", io_operators[0].c_str());
        parse_commands(io_args[0]);
        return;
    }
    string command = io_args[0];

    //Stores file path from which input is taken
    string input_fpath = "";
    //Stores file path to which output is provided
    string output_fpath = "";

    //Stores file descriptor from which input is taken
    int input_fd = 0;
    //Stores file dexcriptor to which output is provided
    int output_fd = 1;
    //Stores the if the output is to be appended or not
    bool append = false;

    for(int i = 1; i < io_args.size(); i++) {
        string filepath = io_args[i];
        //Remove starting and trailing whitespaces 
        while(filepath.at(0) == ' ') filepath = filepath.substr(1);
        while(filepath.at(filepath.size()-1) == ' ') filepath = filepath.substr(0, filepath.size()-1);
        //Remove quotes
        if(filepath.at(0) == filepath.at(filepath.size()-1) && (filepath.at(0) == '\'' || filepath.at(0) == '\"')) 
            filepath = filepath.substr(1,filepath.size()-2);
        
        string redirect_type = io_operators[i-1];
        //Output Redirection encountered
        if(redirect_type == ">" || redirect_type == ">>") {
            if(redirect_type == ">") {
                output_fpath = filepath;
                append = false;
            }
            if(redirect_type == ">>") {
                output_fpath = filepath;
                append = true;
            }
        }
        //Input Redirection encountered
        if(redirect_type == "<") {
            input_fpath = filepath;
        }
    }

    int terminal_in;
    int terminal_out;

    if(input_fpath != "") {
        //Duplicating standard terminal input
        terminal_in = dup(0);
        if(terminal_in == -1) {
            perror("Error in duplicating STDIN_FILENO");
            return;
        }
        input_fd = open(input_fpath.c_str(), O_RDONLY);
        //Changing input from STDIN_FILENO to input_fd
        if(dup2(input_fd,0) == -1) {
            perror("Error encountered in changing terminal input");
            return;
        }
    }
    if(output_fpath != "") {
        //Duplicating standard terminal output
        terminal_out = dup(1);
        if(terminal_out == -1) {
            perror("Error in duplicating STDOUT_FILENO");
            return;
        }
        if(append) output_fd = open(output_fpath.c_str(), O_WRONLY | O_CREAT | O_APPEND, 0644);
        else output_fd = open(output_fpath.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644);
        //Changing input from STDOUT_FILENO to output_fd
        if(dup2(output_fd,1) == -1) {
            perror("Error encountered in changing terminal output");
            return;
        }
    }
    
    //Running commands
    parse_commands(command);

    if(input_fpath != "") {
        //Changing back to original standard input
        if(dup2(terminal_in,0) == -1) {
            perror("Error encountered in changing back terminal input");
            return;
        }
        close(terminal_in);
        close(input_fd);
    }
    if(output_fpath != "") {
        //Changing back to original standard output
        if(dup2(terminal_out,1) == -1) {
            perror("Error encountered in changing back terminal output");
            return;
            close(terminal_out);
            close(output_fd);
        }
    }
}

//Function to parse individual command lines and separate them into arguments for I/O redirection using the '>', '>>' or '<' delimiters
void parse_IO(string line) {
    vector<string> redirect_operators;
    for(int i = 0; i < line.size(); i++) {
        char ch = line.at(i);
        if(ch == '>') {
            if(i != line.size()-1 && line.at(i+1) == '>') {
                redirect_operators.push_back(">>");
                i++;
            }
            else redirect_operators.push_back(">"); 
        }
        if(ch == '<') redirect_operators.push_back("<");
    }
    vector<string> io_args;
    char* io_argument = strtok(line.data(), "<>");
    while(io_argument != NULL) {
        io_args.push_back(io_argument);
        io_argument = strtok(NULL, "<>");
    }
    if(redirect_operators.size() != io_args.size()-1) {
        printf("Incorrect arrangement of I/O redirection operators\n");
        return;
    }
    run_IO(redirect_operators, io_args);
}

//Function to perform pipelining
void run_pipes(vector<string> piped_commands){
    //n = no. of piped commands
    int n = piped_commands.size();

    //Initializing file descriptor pairs for n-1 pipes 
    int pipe_fds[n-1][2];

    //Creating n-1 pipes
    for(int i = 0; i < n-1; i++) {
        if(pipe(pipe_fds[i]) == -1) {
            perror("Error encountered in creating pipes");
            return;
        }
    }

    //Setting up pipes and creating n child processes
    for(int i = 0; i < n; i++) {
        int pid = fork();
        //Forking error
        if(pid == -1) {
            perror("Error encountered in forking for pipelining");
            return;
        }
        //Child process
        else if(pid == 0) {
            //Checking if the process refers to the first piped command
            //If NOT: get input from read end of previous pipe
            if(i != 0) {
                if(dup2(pipe_fds[i-1][0],0) == -1) {
                    perror("Error in duplicating process for pipelining");
                    _exit(1);
                }
            }
            //Checking if the process refers to the last piped command
            //If NOT: send output to write end of next pipe
            if(i != n-1) {
                if(dup2(pipe_fds[i][1],1) == -1) {
                    perror("Error in duplicating process for pipelining");
                    _exit(1);
                }
            }

            //Closing all pipes present in the child process (each child process has a copy of the pipes)
            for(int j = 0; j < n-1; j++) {
                //Closing read end of jth pipe
                if(close(pipe_fds[j][0]) == -1) {
                    perror("Error encountered in closing input end of pipe");
                    _exit(1);
                }
                //Closing output write of jth pipe
                if(close(pipe_fds[j][1]) == -1) {
                    perror("Error encountered in closing output end of pipe");
                    _exit(1);
                }
            }

            bool hasIO = (piped_commands[i].find('>') != string::npos || piped_commands[i].find('<') != string::npos);
            //IO Redirection present - parsing IO
            if(hasIO) parse_IO(piped_commands[i]);
            //Directly parsing commands
            else parse_commands(piped_commands[i]);
            _exit(0);
        }
    }

    //Parent process - only the parent process reaches here
    
    //Closing all pipes present in the parent process itself - since they are no longer required
    for(int i = 0; i < n-1; i++) {
        //Closing read end of ith pipe
        if(close(pipe_fds[i][0]) == -1) {
            perror("Error encountered in closing input end of pipe");
            return;
        }
        //Closing write end of ith pipe
        if(close(pipe_fds[i][1]) == -1) {
            perror("Error encountered in closing output end of pipe");
            return;
        }
    }

    //Waiting for all child processes to finish execution
    for(int i = 0; i < n; i++) wait(NULL);
}

//Function to parse individual command lines and separate them into arguments for piping using the '|' delimiter
void parse_pipes(string line) {
    vector<string> piped_commands;
    char* piped_comm = strtok(line.data(), "|");
    while(piped_comm != NULL) {
        piped_commands.push_back(piped_comm);
        piped_comm = strtok(NULL, "|");
    }
    run_pipes(piped_commands);
}

//Function to parse the line read by the command and separate individual command lines using the ';' delimiter
void parse_lines(string line) {
    vector<string> comm_lines;
    char* command_line = strtok(line.data(), ";");
    while(command_line != NULL) {
        comm_lines.push_back(command_line);
        command_line = strtok(NULL, ";");
    }
    for(int i = 0; i < comm_lines.size(); i++) {
        bool hasPipe = (comm_lines[i].find('|') != string::npos);
        bool hasIO = (comm_lines[i].find('>') != string::npos || comm_lines[i].find('<') != string::npos);
        //Pipes present - parsing pipes
        if(hasPipe) parse_pipes(comm_lines[i]);
        //IO Redirection present - but pipes not present - directly parsing IO
        else if(hasIO) parse_IO(comm_lines[i]);
        //Directly parsing commands
        else parse_commands(comm_lines[i]);
        if(exitTerminal) break;
    }
}