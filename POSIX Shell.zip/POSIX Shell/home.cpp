#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <termios.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <utility>

#include "shell_commands.h"

using namespace std;

//Function to set home directory
void setHome(string home_directory) {
    /*
    int home_file = open("home.txt", O_CREAT | O_WRONLY, 0600);
    if(home_file == -1) {
        perror("Error encountered in accessing home directory records");
        _exit(1);
    }
    if(write(home_file, home_directory.c_str(), home_directory.size()) == -1) {
        perror("Error encountered in saving home directory in records");
        _exit(1);
    }
    close(home_file);
    */
    hpath = home_directory;
}

//Function to retrieve home directory path
string getHome() {
    /*
    int home_file = open("home.txt", O_RDONLY);
    if(home_file == -1) {
        perror("Error encountered in accessing home directory records");
        _exit(1);
    }
    string home_directory = "";
    char buffer[1];
    while(true) {
        int check =  read(home_file, buffer, 1);
        if(check == -1) {
            perror("Error encountered in reading home directory from records");
            _exit(1);
        }
        if(check == 0) break;
        home_directory += string(buffer);
    }
    */
    return hpath;
}