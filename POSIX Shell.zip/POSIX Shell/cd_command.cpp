#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <termios.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <utility>

#include "shell_commands.h"

using namespace std;

//Function to implement cd command on user-made shell terminal
void cd(vector<string> command_args) {
    string command = command_args[0];
    if(command != "cd") {
        printf("Erroneous access of cd command!\n");
        exit(1);
    }
    if(command_args.size() > 2) {
        printf("cd: too many arguments\n");
        return;
    }
    string home_directory = getHome();
    string curr_directory = currentpath();
    string new_directory;
    //Only cd or cd ~
    if(command_args.size() == 1 || command_args[1] == "~") {
        new_directory = home_directory;
    }
    //cd . ignored (directory remains same)
    //cd ..
    else if(command_args[1] == "..") {
        if(curr_directory.find('/') != string::npos) {
            int index = curr_directory.rfind('/');
            if(index == curr_directory.find('/')) new_directory = "/";
            else new_directory = curr_directory.substr(0, index);
        } 
    }
    //cd -
    else if(command_args[1] == "-") {
        new_directory = ppath;
        printf("%s\n", new_directory.c_str());
    }
    //cd <path>
    else {
        new_directory = command_args[1];
        //In '~/<path>'
        if(new_directory.at(0) == '~') {
            new_directory = home_directory + new_directory.substr(1);
        }
    }

    if(chdir(new_directory.c_str()) == -1) {
        perror("cd");
        return;
    }
    ppath = cpath;
    cpath = currentpath();
}