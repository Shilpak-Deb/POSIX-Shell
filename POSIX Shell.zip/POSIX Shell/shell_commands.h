#ifndef SHELLCOMM
#define SHELLCOMM

#include <string>
#include <vector>

using namespace std;

//Header file to access the various user-created POSIX Shell commands

//External Global Variables
extern bool exitTerminal;
extern string cpath;
extern string hpath;
extern string ppath;
extern int current_pid;
extern int arrow_index;
extern string data_read;

//misc.cpp
string hostname();
string username();
string systemname();
string currentpath();
int terminalwidth();
int terminalheight();
void terminal_rawmode(bool flag);
bool hasSpecialChar(string s);
string read_manpage(string command);
string prefix_of(vector<string> arr);
vector<string> match_command(string command);
vector<string> match_filedir(string command, string filedir);

//home.cpp
void setHome(string home_directory);
string getHome();

//signals.cpp
void sig_stop(int sigval);
void sig_int(int sigval);

//shell.cpp
string prompt();
string readline();
void run_command(vector<string>& comm_args, bool is_background);
void parse_commands(string line);
void run_IO(vector<string> operators, vector<string> io_args);
void run_pipes(vector<string> piped_commands);
void parse_IO(string line);
void parse_pipes(string line);
void parse_lines(string line);

//echo_command.cpp
vector<string> get_parts(string argument);
void print_echo(vector<string> command_args);

//cd_command.cpp
void cd(vector<string> command_args);

//ls_command.cpp
bool isFile(string path);
vector<string> read_directory(string path = "", bool is_directory = false, bool is_hidden = false, bool read_all = false);
int blocks_in(string path, bool is_hidden);
void run_ls(string path, bool show_hidden, bool show_long);
bool valid_ls_flag(string flag);
void show_ls(vector<string> command_args);

//search_command.cpp
bool present_in(string target, string path);
void search_in(vector<string> command_args);

//history_command.cpp
vector<string> get_history();
void set_history(string record);
void history(vector<string> command_args);
string up_arrow();
string down_arrow();
string autocomplete1(string line);
void autocomplete2(string line);

//pinfo_command.cpp
bool is_foreground(int pid);
string process_status(int pid);
string process_vsize(int pid);
string process_exe(int pid);
void pinfo(vector<string> command_args);

#endif