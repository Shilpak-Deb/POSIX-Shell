#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <termios.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <utility>

#include "shell_commands.h"

using namespace std;

//Global variable to keep track of arrow index: -1 represents current command being typed
int arrow_index = -1;

//Function to get a vector of strings that represent each line of command(s) entered by the user
vector<string> get_history() {
    string hist_path = hpath + "/history.txt";
    int hist_file = open(hist_path.c_str(), O_RDONLY);
    if(hist_file == -1) {
        perror("history");
        close(hist_file);
        exit(1);
    }
    vector<string> hist;
    string record = "";
    char buffer[1024];
    while(true) {
        int bytes_r = read(hist_file, buffer, 1024);
        if (bytes_r == -1) {
            perror("history");
            close(hist_file);
            exit(1);
        }
        if (bytes_r == 0) break;
        for (int i = 0; i < bytes_r; i++) {
            if (buffer[i] == '\n') {
                hist.push_back(record);
                record.clear();
            } 
            else record += buffer[i];
        }
    }
    close(hist_file);
    return hist;
}

//Function to update history records
void set_history(string record) {
    vector<string> hist = get_history();
    string hist_path = hpath + "/history.txt";
    if(hist.size() > 0 && hist[hist.size()-1] == record) return;
    int hist_file = open(hist_path.c_str(), O_WRONLY | O_TRUNC);
    if(hist_file == -1) {
        perror("history");
        _exit(1);
    }
    if(hist.size() == 20) {
        for(int i = 1; i < hist.size(); i++) {
            string rec = hist[i] + "\n";
            if(write(hist_file, rec.c_str(), rec.size()) == -1) {
                perror("history");
                close(hist_file);
                _exit(1);
            }
        }
        record += "\n";
        if(write(hist_file, record.c_str(), record.size()) == -1) {
            perror("history");
            close(hist_file);
            _exit(1);
        }
    }
    else {
        for(int i = 0; i < hist.size(); i++) {
            string rec = hist[i] + "\n";
            if(write(hist_file, rec.c_str(), rec.size()) == -1) {
                perror("history");
                close(hist_file);
                _exit(1);
            }
        }
        record += "\n";
        if(write(hist_file, record.c_str(), record.size()) == -1) {
            perror("history");
            close(hist_file);
            _exit(1);
        }
    }
    close(hist_file);
}

//Function to implement user-made history command
void history(vector<string> command_args) {
    if(command_args[0] != "history") {
        printf("Erroneous access of history command!\n");
        exit(1);
    }
    if(command_args.size() > 2) {
        printf("history: too many arguments\n");
        return;
    }
    int n = 10;
    if(command_args.size() == 1) n = 10;
    else n = stoi(command_args[1]);
    if(n < 0 || n > 20) {
        printf("history: %d: invalid option\n", n);
        return;
    }
    vector<string> hist = get_history();
    int i = hist.size() - n;
    if(i < 0) i = 0;
    for(; i < hist.size(); i++) {
        printf("%s\n", hist[i].c_str());
    }
}

//Function to implement Up Arrow Key
string up_arrow(){
    arrow_index++;
    vector<string> hist = get_history();
    if(arrow_index >= hist.size()) arrow_index = hist.size()-1;
    int hindex = hist.size()-arrow_index-1;
    if(hindex < 0) hindex = 0;

    printf("\r");
    for(int i = 0; i < terminalwidth(); i++) printf(" ");
    printf("\r%s%s", (prompt()).c_str(), hist[hindex].c_str());
    return hist[hindex];
}

//Function to implement Down Arrow Key
string down_arrow(){
    arrow_index--;
    if(arrow_index < -1) arrow_index = -1;
    vector<string> hist = get_history();
    int hindex = hist.size()-arrow_index-1;
    if(hindex < 0) hindex = 0;

    printf("\r");
    for(int i = 0; i < terminalwidth(); i++) printf(" ");

    if(arrow_index == -1) {
        printf("\r%s%s", (prompt()).c_str(), data_read.c_str());
        return data_read;
    }

    printf("\r%s%s", (prompt()).c_str(), hist[hindex].c_str());
    return hist[hindex];
}

//Function to implement autocomplete function when pressing tab key once
string autocomplete1(string line) {
    bool only_whitespaces = true;
    for(int i = 0; i < line.size(); i++) {
        if(line.at(i) != ' ') {
            only_whitespaces = false;
            break;
        }
    }
    if(only_whitespaces) return line;
    string line_copy = line;
    bool isCommand = true;
    char* command_line = strtok(line.data(), ";|");
    string fragment;
    while(command_line != NULL) {
        fragment = string(command_line);
        command_line = strtok(NULL, ";|");
    }
    while(fragment.at(0) == ' ') fragment = fragment.substr(1);
    string fragment_copy = fragment;

    vector<string> comm_args;
    char* comm_argument = strtok(fragment.data(), " ");
    while(comm_argument != NULL) {
        comm_args.push_back(comm_argument);
        comm_argument = strtok(NULL, " ");
    }

    if(comm_args.size() == 1 && fragment_copy.size() == comm_args[0].size()) isCommand = true;
    else isCommand = false;

    if(fragment_copy.at(fragment_copy.size()-1) == ' ') comm_args.push_back("");

    if(isCommand) {
        vector<string> commlist = match_command(fragment_copy);
        printf("\r");
        for(int i = 0; i < terminalwidth(); i++) printf(" ");
        printf("\r%s", (prompt()).c_str());
        string leading_line = line_copy.substr(0, line_copy.size()-fragment_copy.size());
        printf("%s", leading_line.c_str());
        string completed_portion;
        if(commlist.size() == 1) completed_portion = commlist[0] + " ";
        else if(commlist.size() != 0) completed_portion = prefix_of(commlist);
        else completed_portion = fragment_copy;
        printf("%s", completed_portion.c_str());
        return leading_line + completed_portion;
    }
    else {
        string command = comm_args[0];
        string incomplete_portion = comm_args[comm_args.size()-1];
        if(incomplete_portion == "") return line_copy;
        printf("\r");
        for(int i = 0; i < terminalwidth(); i++) printf(" ");
        printf("\r%s", (prompt()).c_str());
        string leading_line = line_copy.substr(0, line_copy.size()-incomplete_portion.size());
        printf("%s", leading_line.c_str());
        string completed_portion;
        vector<string> fdlist = match_filedir(command, incomplete_portion);
        if(fdlist.size() != 0) completed_portion = prefix_of(fdlist); 
        else completed_portion = incomplete_portion;
        printf("%s", completed_portion.c_str());
        return leading_line + completed_portion;
    }
}

//Function to implement autocomplete function when pressing tab key twice
void autocomplete2(string line) {
    bool only_whitespaces = true;
    for(int i = 0; i < line.size(); i++) {
        if(line.at(i) != ' ') {
            only_whitespaces = false;
            break;
        }
    }
    if(only_whitespaces) return;
    string line_copy = line;
    bool isCommand = true;
    char* command_line = strtok(line.data(), ";|");
    string fragment;
    while(command_line != NULL) {
        fragment = string(command_line);
        command_line = strtok(NULL, ";|");
    }
    while(fragment.at(0) == ' ') fragment = fragment.substr(1);
    string fragment_copy = fragment;

    vector<string> comm_args;
    char* comm_argument = strtok(fragment.data(), " ");
    while(comm_argument != NULL) {
        comm_args.push_back(comm_argument);
        comm_argument = strtok(NULL, " ");
    }

    if(comm_args.size() == 1 && fragment_copy.size() == comm_args[0].size()) isCommand = true;
    else isCommand = false;

    if(fragment_copy.at(fragment_copy.size()-1) == ' ') comm_args.push_back("");

    if(isCommand) {
        vector<string> commlist = match_command(fragment_copy);
        printf("\n");
        for(int i = 0; i < commlist.size(); i++) printf("%s ", commlist[i].c_str());
        printf("\n");
    }
    else {
        string command = comm_args[0];
        string incomplete_portion = comm_args[comm_args.size()-1];
        vector<string> fdlist = match_filedir(command, incomplete_portion);
        printf("\n");
        for(int i = 0; i < fdlist.size(); i++) printf("%s ", fdlist[i].c_str());
        printf("\n");
    }
}