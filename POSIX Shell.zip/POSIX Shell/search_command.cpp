#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <termios.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <utility>

#include "shell_commands.h"

using namespace std;

//Function to check is a target file/directory is present in given directory
bool present_in(string target, string path) {
    bool flag = false;
    //Checking for all files in current directory
    vector<string> dir_contents = read_directory(path, false, false, true);
    if(!dir_contents.empty()) {
        for(int i = 0; i < dir_contents.size(); i++) {
            if(target == dir_contents[i]) {
                flag = true;
                break;
            }
        }
    }
    if(flag) return flag;
    dir_contents.clear();
    //Checking for all files in current directory
    dir_contents = read_directory(path, true, false, true);
    if(!dir_contents.empty()) {
        for(int i = 0; i < dir_contents.size(); i++) {
            if(target == dir_contents[i]) {
                flag = true;
                break;
            }
        }
    }
    if(flag) return flag;
    //Checking recursively for all directories in current directory
    for(int i = 0; i < dir_contents.size(); i++) {
        string dir_path = path + "/" + dir_contents[i];
        flag = present_in(target, dir_path);
        if(flag) return flag;
    }
    return flag;
}

//Function to implement user-made search command
void search_in(vector<string> command_args) {
    if(command_args[0] != "search") {
        printf("Erroneous access of search command!\n");
        exit(1);
    }
    if(command_args.size() > 2) {
        printf("search: too many arguments\n");
        return;
    }
    if(command_args.size() < 2) {
        printf("search: too few arguments\n");
        return;
    }
    string target = command_args[1];
    if(target.at(0) == target.at(target.size()-1) && (target.at(0) == '\'' || target.at(0) == '\"')) {
        target = target.substr(1, target.size()-2);
    }
    if(present_in(target, currentpath())) printf("True\n");
    else printf("False\n");
}