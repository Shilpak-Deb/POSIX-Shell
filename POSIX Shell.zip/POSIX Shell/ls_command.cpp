#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <termios.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <utility>

#include "shell_commands.h"

using namespace std;

//Function to check if a path refers to a valid file
bool isFile(string path) {
    struct stat filestat;
    if(stat(path.c_str(), &filestat) == -1) {
        return false;
    }
    return S_ISREG(filestat.st_mode);
}

//Function to return the names of all hidden/non-hidden files/directories present in a directory
vector<string> read_directory(string path, bool is_directory, bool is_hidden, bool read_all) {
    //If no path is specified
    if(path == "") path = currentpath();
    //Utilizing opendir() to open a directory (based on path provided)
    DIR* current_dir = opendir(path.c_str());
    if(current_dir == NULL) {
        perror("Error encountered in opening directory based on path provided");
        exit(1);
    }
    vector<string> dir_contents;        //Vector to store all the contents of current directory
    //Accessing all files and directories present in current directory (based on path provided)
    while(true) {
        struct dirent* dir_entry = readdir(current_dir);
        if(dir_entry == NULL) break;
        string entry = string(dir_entry->d_name);
        if(is_directory && dir_entry->d_type == DT_DIR) {
            if(read_all && entry != ".." && entry != ".") dir_contents.push_back(entry);
            else if(is_hidden && entry.at(0) == '.' && entry != ".." && entry != ".") dir_contents.push_back(entry);
            else if(!is_hidden && entry.at(0) != '.') dir_contents.push_back(entry);
        }
        if(!is_directory && dir_entry->d_type != DT_DIR) {
            if(read_all && entry != ".." && entry != ".") dir_contents.push_back(entry);
            else if(is_hidden && entry.at(0) == '.'&& entry != ".." && entry != ".") dir_contents.push_back(entry);
            else if(!is_hidden && entry.at(0) != '.') dir_contents.push_back(entry);
        }
    }
    //Closing the current directory
    if(closedir(current_dir) == -1) {
        perror("Error encountered in closing directory");
        exit(1);
    }
    return dir_contents;
}

int blocks_in(string path, bool is_hidden) {
    int total = 0;
    //Checking for all files in current directory
    vector<string> dir_contents = read_directory(path, false, is_hidden, is_hidden);
    if(!dir_contents.empty()) {
        for(int i = 0; i < dir_contents.size(); i++) {
            struct stat file_stat;
            string file_path = path + "/" + dir_contents[i];
            if(stat(file_path.c_str(), &file_stat) == -1) {
                perror("Error encountered in accessing status of file");
                return 0;
            }
            total += (file_stat.st_blocks)/2;
        }
    }
    //Checking for all files in current directory
    dir_contents = read_directory(path, true, is_hidden, is_hidden);
    if(!dir_contents.empty()) {
        for(int i = 0; i < dir_contents.size(); i++) {
            struct stat subdir_stat;
            string subdir_path = path + "/" + dir_contents[i];
            if(stat(subdir_path.c_str(), &subdir_stat) == -1) {
                perror("Error encountered in accessing status of file");
                return 0;
            }
            total += (subdir_stat.st_blocks)/2;
        }
    }
    //Adding values of "." and ".."
    if(is_hidden) total += 8;
    return total;
}

//Function to implement functionality of ls command
void run_ls(string path, bool show_hidden, bool show_long) {
    if(isFile(path)) {
        if(!show_long) printf("%s\n", path.c_str());
        else {
            //Printing permissions
            struct stat filestat;
            if(stat(path.c_str(), &filestat) == -1) {
                perror("Error encountered in accessing status of file");
                return;
            }
            printf("-");
            if(filestat.st_mode & 0400) printf("r");
            else printf("-");
            if(filestat.st_mode & 0200) printf("w");
            else printf("-");
            if(filestat.st_mode & 0100) printf("x");
            else printf("-");
            if(filestat.st_mode & 0040) printf("r");
            else printf("-");
            if(filestat.st_mode & 0020) printf("w");
            else printf("-");
            if(filestat.st_mode & 0010) printf("x");
            else printf("-");
            if(filestat.st_mode & 0004) printf("r");
            else printf("-");
            if(filestat.st_mode & 0002) printf("w");
            else printf("-");
            if(filestat.st_mode & 0001) printf("x");
            else printf("-");

            printf(" ");

            //Printing hard links
            printf("%d", (int)filestat.st_nlink);

            printf(" ");

            //Printing owner name of file
            struct passwd* owner_data = getpwuid(filestat.st_uid);
            string owner_name = string(owner_data->pw_name);
            printf("%s", owner_name.c_str());
            
            printf(" ");

            //Printing group name of file
            struct group* group_data = getgrgid(filestat.st_gid);
            string group_name = string(group_data->gr_name);
            printf("%s", group_name.c_str());

            printf(" ");

            //Printing file size
            string entry_size = to_string(filestat.st_size);
            printf("%s", entry_size.c_str());

            printf(" ");

            //Printing last modified time for file
            struct tm* modification_time = localtime(&filestat.st_mtime);
            char time_buffer[100];
            //Month
            strftime(time_buffer, 100, "%b", modification_time);
            printf("%s ", (string(time_buffer)).c_str());
            //Day
            strftime(time_buffer, 100, "%d", modification_time);
            printf("%s ", (string(time_buffer)).c_str());
            //Time
            strftime(time_buffer, 100, "%H:%M", modification_time);
            printf("%s", (string(time_buffer)).c_str());

            printf(" ");

            //Printing name of file
            if(path.find('/') != string::npos) {
                int index = path.rfind('/');
                if(index != path.size()-1) path = path.substr(index+1);
            }

            printf("%s\n", path.c_str());
        }
        return;
    }

    //Utilizing opendir() to open a directory (based on path provided)
    DIR* current_dir = opendir(path.c_str());
    if(current_dir == NULL) {
        perror("ls: cannot access path");
        return;
    }

    vector<string> dir_contents;        //Vector to store all the contents of current directory
    map<string, bool> is_directory;         //Map to check if an entry is a directory or not

    //Accessing all files and directories present in current directory (based on path provided)
    while(true) {
        struct dirent* dir_entry = readdir(current_dir);
        if(dir_entry == NULL) break;
        string entry = string(dir_entry->d_name);
        is_directory[entry] = dir_entry->d_type == DT_DIR;
        if(entry.at(0) == '.' && show_hidden) dir_contents.push_back(entry);
        else if(entry.at(0) != '.') dir_contents.push_back(entry);
    }

    //Closing the current directory
    if(closedir(current_dir) == -1) {
        perror("Error encountered in closing directory while utilizing the ls command");
        return;
    }

    int n = dir_contents.size();

    //Checking the position of "." directory
    if(show_hidden) {
        int index = 0;
        for(int i = 0; i < n; i++) {
            if(dir_contents[i] == ".") {
                index = i;
                break;
            }
        }
        swap(dir_contents[0], dir_contents[index]);
    }

    //Sorting the names of the files and directories in lexicographical order (case insensitive) (and separately for files and directories)
    int hidden = (show_hidden)?1:0;

    sort(dir_contents.begin()+hidden, dir_contents.end(), [](string first, string second) {
        string temp_first = first;
        string temp_second = second;
        if(temp_first.at(0) == '.') temp_first = temp_first.substr(1);
        if(temp_second.at(0) == '.') temp_second = temp_second.substr(1);
        transform(temp_first.begin(), temp_first.end(), temp_first.begin(), ::tolower);
        transform(temp_second.begin(), temp_second.end(), temp_second.begin(), ::tolower);
        return (temp_first < temp_second);
    });
    for(int i = hidden; i < n;) {
        if(dir_contents[i] == "..") {
            i++;
            continue;
        }
        int start_index = i;
        int end_index = i;
        if(end_index >= n) break;
        while(true) {
            char schar = dir_contents[start_index].at(0);
            if(schar == '.') schar = dir_contents[start_index].at(1);
            char echar = tolower(dir_contents[end_index].at(0));
            if(echar == '.') echar = dir_contents[end_index].at(1);
            if(schar != echar) break;
            end_index++;
            if(end_index >= n) break;
        }
        i = end_index+1;
        if(end_index >= n) end_index--;
        vector<string> directories;
        vector<string> files;
        for(int j = start_index; j < end_index; j++) {
            if(is_directory[dir_contents[j]]) directories.push_back(dir_contents[j]);
            else files.push_back(dir_contents[j]);
        }
        for(int j = 0; j < directories.size(); j++) dir_contents[start_index++] = directories[j];
        for(int j = 0; j < files.size(); j++) dir_contents[start_index++] = files[j];
    }






    //Checking if data is asked to be displayed in long mode
    if(show_long) {
        int total = blocks_in(path, show_hidden);
        printf("total: %d\n", total);

        vector<vector<string>> long_data;
        for(int i = 0; i < dir_contents.size(); i++) {
            string entry = dir_contents[i];
            string entry_path = path + "/" + entry;

            vector<string> entry_data;

            struct stat entry_status;
            if(stat(entry_path.c_str(), &entry_status) == -1) {
                perror("Error encountered in accessing status of file/directory");
                return;
            }

            string permissions = "";

            //Storing permissions of file/directory
            if(is_directory[entry]) permissions += "d";
            else permissions += "-";
            if(entry_status.st_mode & 0400) permissions += "r";
            else permissions += "-";
            if(entry_status.st_mode & 0200) permissions += "w";
            else permissions += "-";
            if(entry_status.st_mode & 0100) permissions += "x";
            else permissions += "-";
            if(entry_status.st_mode & 0040) permissions += "r";
            else permissions += "-";
            if(entry_status.st_mode & 0020) permissions += "w";
            else permissions += "-";
            if(entry_status.st_mode & 0010) permissions += "x";
            else permissions += "-";
            if(entry_status.st_mode & 0004) permissions += "r";
            else permissions += "-";
            if(entry_status.st_mode & 0002) permissions += "w";
            else permissions += "-";
            if(entry_status.st_mode & 0001) permissions += "x";
            else permissions += "-";

            entry_data.push_back(permissions);
            

            //Storing no. of hard links for file/directory
            string hard_links = to_string(entry_status.st_nlink);

            entry_data.push_back(hard_links);


            //Storing owner name of file/directory
            struct passwd* owner_data = getpwuid(entry_status.st_uid);
            string owner_name = string(owner_data->pw_name);

            entry_data.push_back(owner_name);


            //Storing group name of file/directory
            struct group* group_data = getgrgid(entry_status.st_gid);
            string group_name = string(group_data->gr_name);

            entry_data.push_back(group_name);


            //Storing file size for file/directory
            string entry_size = to_string(entry_status.st_size);

            entry_data.push_back(entry_size);


            //Storing last modified time for file/directory
            struct tm* modification_time = localtime(&entry_status.st_mtime);
            char time_buffer[100];
            //Month
            strftime(time_buffer, 100, "%b", modification_time);
            entry_data.push_back(string(time_buffer));
            //Day
            strftime(time_buffer, 100, "%d", modification_time);
            entry_data.push_back(string(time_buffer));
            //Time
            strftime(time_buffer, 100, "%H:%M", modification_time);
            entry_data.push_back(string(time_buffer));


            //Storing name of file/directory
            entry_data.push_back(entry);

            long_data.push_back(entry_data);
        }
        //Finding max width of column
        vector<int> col_width(9);
        for(int j = 0; j < 9; j++) {
            col_width[j] = 0;
            for(int i = 0; i < dir_contents.size(); i++) {
                col_width[j] = max(col_width[j], (int)long_data[i][j].size());
            }
        }
        //Displaying the data on terminal
        for(int i = 0; i < dir_contents.size(); i++) {
            for(int j = 0; j < 9; j++) {
                int white_spaces = col_width[j] - long_data[i][j].size();
                for(int k = 0; k < white_spaces; k++) printf(" ");
                printf("%s ", long_data[i][j].c_str());
            }
            printf("\n");
        }
        return;
    }





    if(isatty(1)) {
        //Finding the width of the current terminal
        int t_width = terminalwidth();
        
        //Adjusting the row and column size for displaying directory contents
        int cols = 1, rows;
        vector<int> colsize;
        while(true) {
            colsize.clear();
            rows = n / cols;
            if(rows*cols < n) rows++;
            int total_length = 0;
            for(int i = 0; i < rows; i++) {
                int max_length = 0;         //Max length of entry in particular column
                for(int j = 0; j < cols; j++) {
                    int index = i*cols + j;
                    if(index >= n) break;
                    int entry_size = dir_contents[index].size();
                    max_length = max(max_length, entry_size);
                }
                total_length += max_length+2;
                colsize.push_back(max_length);
            }
            if(total_length > t_width) cols++;
            else break;
        }

        //Displaying the contents of the directory
        for(int j = 0; j < cols; j++) {
            for(int i = 0; i < rows; i++) {
                int index = i*cols + j;
                if(index >= n) break;
                if(hasSpecialChar(dir_contents[index])) printf("'");
                else printf(" ");
                printf("%s", (dir_contents[index]).c_str());
                if(hasSpecialChar(dir_contents[index])) printf("'");
                else printf(" ");
                int spaces = colsize[i]-dir_contents[index].size();
                for(int k = 0; k < spaces; k++) printf(" ");
            }
            printf("\n");
        }
    }
    else {
        for(int i = 0; i < dir_contents.size(); i++) {
            printf("%s\n", dir_contents[i].c_str());
        }
    }
}

//Function to check if a string contains is a valid flag for user-made 'ls' command
bool valid_ls_flag(string flag) {
    if(flag.at(0) != '-') return false;
    for(int i = 1; i < flag.size(); i++) {
        if(flag.at(i) != 'a' && flag.at(i) != 'l') {
            printf("ls: invalid option -- %c\n", flag.at(i));
            return false;
        }
    }
    return true;
}

//Function to implement user-made 'ls' command on terminal (wrapper)
void show_ls(vector<string> command_args) {
    if(command_args[0] != "ls") {
        printf("Erroneous access of ls command!\n");
        exit(1);
    }
    if(command_args.size() == 1) {
        run_ls(currentpath(), false, false);
        return;
    }
    if(command_args.size() >= 2) {
        bool flag_l = false;
        bool flag_a = false;
        int path_count = 0;
        vector<string> paths;

        bool path_present = false;
        for(int i = 1; i < command_args.size(); i++) {
            string argument = command_args[i];
            //Flag handling
            if(argument.at(0) == '-') {
                if(!valid_ls_flag(argument)) return;
                if(argument.find('l') != string::npos) flag_l = true;
                if(argument.find('a') != string::npos) flag_a = true;
            }
            //Path handling
            else {
                path_count++;
                paths.push_back(command_args[i]);
                path_present = true;
            }
        }

        if(!path_present) {
            run_ls(currentpath(), flag_a, flag_l);
            return;
        }

        sort(paths.begin(), paths.end());

        for(int k = 0; k < paths.size(); k++) {
            //..Perform individual ls operations
            string run_path = paths[k];
            if(run_path == ".") run_path = currentpath();
            if(run_path == "..") {
                string current_path = currentpath();
                if(current_path.find('/') != string::npos) {
                    int index = current_path.rfind('/');
                    if(index == current_path.find('/')) run_path = "/";
                    else run_path = current_path.substr(0, index);
                }
                else {
                    printf("ls: cannot access '%s': No such file or directory\n", run_path.c_str());
                }
            }
            if(run_path == "~") run_path = getHome();
            if(run_path.at(0) == '~') {
                run_path = getHome() + run_path.substr(1);
            }
            if(paths.size() != 1) {
                printf("%s:\n", run_path.c_str());
            }
            run_ls(run_path, flag_a, flag_l);

            if(k != paths.size()-1) printf("\n");
        }
    }
}
