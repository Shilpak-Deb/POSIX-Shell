#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <termios.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <utility>

#include "shell_commands.h"            //User-created header file

using namespace std;

//Variable to keep terminal running
bool exitTerminal = false;
//variable to keep track of home directory
string hpath = "";
//Variable to keep track of current path
string cpath = "";
//Variable to keep track of prev path
string ppath = "";

//Main function that executes an infinite loop to run shell
int main() {
    hpath = currentpath();
    cpath = hpath;
    ppath = hpath;

    //History file creation
    int hist_file = open("history.txt", O_CREAT, 0600);
    if(hist_file == -1) {
        if(errno == EEXIST) {
            close(hist_file);
        }
        else {
            perror("Error encountered in creating history file");
            _exit(1);
        }
    }
    else close(hist_file);

    //Signal handling
    signal(SIGTSTP, sig_stop);
    signal(SIGINT, sig_int);
    
    //Infinite Loop
    while(true) {
        if(current_pid != -1 && (process_status(current_pid) == "T" || process_status(current_pid) == "Z" || process_status(current_pid) == "")) {
            current_pid = -1;
        }
        if(exitTerminal) {
            break;
        }
        printf("\r%s", (prompt()).c_str());
        string line = readline();
        if(line != "") set_history(line);
        parse_lines(line);
    }

    return 0;
}