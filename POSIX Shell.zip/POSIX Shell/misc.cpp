#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <termios.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <utility>

#include "shell_commands.h"

using namespace std;

//Function to return host name 
string hostname() {
    char host_name[256];
    if(gethostname(host_name, 256) == -1) {
        perror("Error encountered in accessing host name");
        return "";
    }
    return string(host_name);
} 

//Function to return user name 
string username() {
    struct passwd* user = getpwuid(getuid());
    if(user == NULL) {
        perror("Error encountered in accessing user name");
        return "";
    }
    return string(user->pw_name);
}

//Function to return system name 
string systemname() {
    struct utsname user;
    if(uname(&user) == -1) {
        perror("Error encountered in accessing system name");
        return "";
    }
    return string(user.sysname);
}

//Function to return current directory path
string currentpath() {
    char curr_path[1024];
    if(getcwd(curr_path, 1024) == NULL) {
        perror("Error encountered in accessing current directory path");
        return "";
    }
    return string(curr_path);
}

//Function to return terminal width
int terminalwidth() {
    struct winsize terminal;
    if(ioctl(1, TIOCGWINSZ, &terminal) == -1) {
        perror("Error encountered in accessing terminal width");
        return 0;
    }
    return terminal.ws_col;
}

//Function to return terminal height
int terminalheight() {
    struct winsize terminal;
    if(ioctl(1, TIOCGWINSZ, &terminal) == -1) {
        perror("Error encountered in accessing terminal height");
        return 0;
    }
    return terminal.ws_row;
}

//Function to set the terminal to raw mode to allow the detection of special keys
void terminal_rawmode(bool flag) {
    static struct termios original_terminal;
    static struct termios raw_terminal;
    if(flag) {
        tcgetattr(0, &original_terminal);
        raw_terminal = original_terminal;
        raw_terminal.c_lflag &= ~(ICANON | ECHO);
        tcsetattr(0, TCSANOW, &raw_terminal);
    }
    else tcsetattr(0, TCSANOW, &original_terminal);
}

//Function to check if a string contains special characters (for ls command)
bool hasSpecialChar(string s) {
    vector<char> special_char = {' ', '*', '?', '!', '\\', '\'', '\"'};
    bool flag = false;
    for(int i = 0; i < s.size(); i++) {
        for(int j = 0; j < special_char.size(); j++) {
            if(s.at(i) == special_char[j]) {
                flag = true;
                break;
            }
        }
        if(flag == true) break;
    }
    return flag;
}

//Functions to get the man page of a command
string read_manpage(string command) {
    if(command == "cd") return "directory";
    int pipe_fd[2];
    if (pipe(pipe_fd) == -1) {
        perror("Error encountered in accessing creating pipe for man page access");
        return "";
    }

    int pid = fork();
    //Error check
    if (pid == -1) {
        perror("Error encountered in forking parent process to access command man page");
        return "";
    }
    //Child process
    else if(pid == 0) {
        if(close(pipe_fd[0]) == -1) {
            perror("Error encountered in closing read end of pipe");
            _exit(1);
        }
        if(dup2(pipe_fd[1], 1) == -1) {
            perror("Error encountered in changing process output");
            _exit(1);
        }
        if(close(pipe_fd[1]) == -1) {
            perror("Error encountered in closing write end of pipe");
            _exit(1);
        }
        string man = "man";
        char * comm_args[3];
        comm_args[0] = man.data();
        comm_args[1] = command.data();
        comm_args[2] = NULL;

        if(execvp(man.data(), comm_args) == -1) {
            perror("Could not execute command");
            _exit(1); 
        }
        _exit(0);
    }
    //Parent process
    else {
        if(close(pipe_fd[1]) == -1) {
            perror("Error encountered in closing write end of pipe");
            return "";
        }
        string manpage;
        char buffer[1024];
        while(true) {
            int bytes_r = read(pipe_fd[0], buffer, 1024);
            if (bytes_r == -1) {
                perror("Error encountered in reading contents of man page");
                close(pipe_fd[0]);
                return "";
            }
            if(bytes_r == 0) break;
            for(int i = 0; i < bytes_r; i++) manpage += buffer[i];
        }
        if(close(pipe_fd[0]) == -1) {
            perror("Error encountered in closing read end of pipe");
            return "";
        }
        waitpid(pid, NULL, 0);
        return manpage;
    }
    return "";
}

//Function to find longest common prfix
string prefix_of(vector<string> arr) {
    string pref = "";
    int minsize = arr[0].size();
    for(int i = 1; i < arr.size(); i++) {
        if(arr[i].size() < minsize) minsize = arr[i].size();
    }
    for(int i = 0; i < minsize; i++) {
        bool matches = true;
        char ch = arr[0].at(i);
        for(int j = 1; j < arr.size(); j++) {
            if(ch != arr[j].at(i)) {
                matches = false;
                break;
            }
        } 
        if(!matches) break;
        else pref += ch;
    }
    return pref;
}

//Function to check for all commands that match with given command
vector<string> match_command(string command) {
    set<string> command_list;
    command_list.insert("exit");
    vector<string> command_directories = {"/bin", "/usr/bin", "/sbin", "/usr/sbin"};
    for(int i = 0; i < command_directories.size(); i++) {
        vector<string> files = read_directory(command_directories[i], false, false, false);
        for(int j = 0; j < files.size(); j++) command_list.insert(files[j]);
    }
    vector<string> comm_list(command_list.begin(), command_list.end());
    vector<string> matched_commands;
    for(int i = 0; i < comm_list.size(); i++) {
        if(comm_list[i].substr(0,command.size()) == command) matched_commands.push_back(comm_list[i]);
    }
    return matched_commands;
}

//Function to match file/directory names depending on specific command
vector<string> match_filedir(string command, string filedir) {
    set<string> filedir_list;
    string manpage = read_manpage(command);
    bool accepts_files = false, accepts_dirs = false;
    if(manpage != "") {
        if(manpage.find("file") != string::npos) accepts_files = true;
        if(manpage.find("directory") != string::npos) accepts_dirs = true;
    }
    if(accepts_files) {
        vector<string> temp = read_directory(currentpath(), false, false, true);
        for(int i = 0; i < temp.size(); i++) filedir_list.insert(temp[i]);
    }
    if(accepts_dirs) {
        vector<string> temp = read_directory(currentpath(), true, false, true);
        for(int i = 0; i < temp.size(); i++) filedir_list.insert(temp[i]+"/");
    }
    vector<string> fd_list(filedir_list.begin(), filedir_list.end());
    vector<string> matched_filedir;
    for(int i = 0; i < fd_list.size(); i++) {
        if(fd_list[i].substr(0,filedir.size()) == filedir) matched_filedir.push_back(fd_list[i]);
    }
    return matched_filedir;
}