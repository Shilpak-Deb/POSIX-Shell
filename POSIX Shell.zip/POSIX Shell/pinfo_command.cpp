#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <termios.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <utility>

#include "shell_commands.h"

using namespace std;

//Function to check if a process is running in foreground
bool is_foreground(int pid) {
    int pgid = getpgid(pid);
    if(pgid == -1) {
        perror("Error in obtaining group id of process");
        return false;
    }
    int foreground_gid = tcgetpgrp(0);
    return (pgid == foreground_gid);
}

//Function to return process status
string process_status(int pid) {
    string status_path = "/proc/" + to_string(pid) + "/stat";
    int status_file = open(status_path.c_str(), O_RDONLY);
    if(status_file == -1) {
        return "";
    }
    char buffer[1024];
    string file_contents = "";
    while(true) {
        int bytes_r = read(status_file, buffer, 1024);
        if (bytes_r == -1) {
            perror("pinfo");
            close(status_file);
            exit(1);
        }
        if(bytes_r == 0) break;
        for(int i = 0; i < bytes_r; i++) file_contents += buffer[i];
    }
    string status = strtok(file_contents.data(), " ");
    status = strtok(NULL, " ");
    status = strtok(NULL, " ");

    if(is_foreground(pid) && (status == "R" || status == "S")) status += "+";

    close(status_file);
    return status;
}

//Function to return virtual memory size (in pages)
string process_vsize(int pid) {
    string memory_path = "/proc/" + to_string(pid) + "/statm";
    int memory_file = open(memory_path.c_str(), O_RDONLY);
    if(memory_file == -1) {
        perror("Error encountered in accessing memory file of process");
        close(memory_file);
        return "";
    }
    char buffer[1024];
    string file_contents = "";
    while(true) {
        int bytes_r = read(memory_file, buffer, 1024);
        if (bytes_r == -1) {
            perror("pinfo");
            close(memory_file);
            exit(1);
        }
        if(bytes_r == 0) break;
        for(int i = 0; i < bytes_r; i++) file_contents += buffer[i];
    }
    string memory = strtok(file_contents.data(), " ");
    close(memory_file);
    return memory;
}

//Function to return executable path of process
string process_exe(int pid) {
    string exec_path = "/proc/" + to_string(pid) + "/exe";
    char buffer[4096];
    int exec_file_len = readlink(exec_path.c_str(), buffer, 4096);
    if(exec_file_len == -1) {
        return "";
    }
    string exe_proc = "";
    for(int i = 0; i < exec_file_len; i++) exe_proc += buffer[i];
    return exe_proc;
}

//Function to implement pinfo command on user-made shell terminal
void pinfo(vector<string> command_args) {
    string command = command_args[0];
    if(command != "pinfo") {
        printf("Erroneous access of pinfo command!\n");
        _exit(1);
    }
    if(command_args.size() > 2) {
        printf("pinfo: too many arguments\n");
        return;
    }
    int pid;
    if(command_args.size() == 1) pid = getpid();
    else {
        bool isNumber = true;
        for(int i = 0; i < command_args[1].size(); i++) {
            if(!isdigit(command_args[1].at(i))) {
                isNumber = false;
                break;
            }
        }
        if(isNumber) pid = stoi(command_args[1]);
        else {
            printf("pinfo: pid: invalid data type of argument\n");
            return;
        }
    }

    if(kill(pid, 0) == -1) {
        perror("pinfo");
        return;
    }

    string status = process_status(pid);
    if(status == "") return;
    string vsize = process_vsize(pid);
    string exec_proc = process_exe(pid);

    printf("pid -- %d\n", pid);
    printf("Process Status -- %s\n", status.c_str());
    printf("memory -- %s\n", vsize.c_str());
    printf("Executable Path -- %s\n", exec_proc.c_str());
}
