#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <termios.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <utility>

#include "shell_commands.h"

using namespace std;


//Function to segment an argument into parts for 'echo' 
vector<string> get_parts(string argument) {
    vector<string> parts;
    string temp = "";
    for(int i = 0; i < argument.size(); i++) {
        char ch = argument.at(i);
        if(ch == '\'' || ch == '\"') {
            temp = "";
            int j = i+1;
            bool closed = false;
            while(j < argument.size()) {
                if(argument.at(j) != ch) {
                    j++;
                }
                else {
                    closed = true;
                    break;
                }
            }
            if(closed) {
                temp = argument.substr(i+1, j-i-1);
                if(i != 0 && argument.at(i-1) == ' ') temp = " " + temp;
                parts.push_back(temp);
                i = j;
                temp = "";
            }
            else {
                temp = argument.substr(i+1);
                if(i != 0 && argument.at(i-1) == ' ') temp = " " + temp;
                parts.push_back(temp);
                break;
            }
        }
        else if(ch != ' ') {
            temp += ch;
            if(i != 0 && argument.at(i-1) == ' ') temp = " " + temp;
            if(i == argument.size()-1 || argument.at(i+1) == ' ' || argument.at(i+1) == '\'' || argument.at(i+1) == '\"') {
                parts.push_back(temp);
                temp = "";
            }
        }
    }
    return parts;
}

//Function to implement user-made echo command
void print_echo(vector<string> command_args) {
    if(command_args[0] != "echo") {
        printf("Erroneous access of echo command!\n");
        exit(1);
    }
    if(command_args.size() == 1) return;
    for(int i = 1; i < command_args.size(); i++) {
        vector<string> parts = get_parts(command_args[i]);
        for(int j = 0; j < parts.size(); j++) {
            printf("%s", parts[j].c_str());
        }
        printf(" ");
    }
    printf("\n");
}