#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <termios.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <utility>

#include "shell_commands.h"

using namespace std;

//Function to handlle the Ctrl -Z signal
void sig_stop(int sigval) {
    if(sigval == SIGTSTP) {
        if(current_pid != -1 && kill(current_pid, SIGTSTP) == -1) {
            perror("Ctrl -Z");
            return;
        }
    }
}

//Function to handle the Ctrl -C signal
void sig_int(int sigval) {
    if(sigval == SIGINT) {
        printf("\r");
        if(current_pid != -1 && kill(current_pid, SIGINT) == -1) {
            perror("Ctrl -C");
            return;
        }
        else current_pid = -1; 
    }
    printf("\r%s", prompt().c_str());
}
